APLIKASI UANG KELUARGA — PROYEK ANDROID

Isi:
- app/src/main/assets/index.html : aplikasi pencatatan keuangan
- MainActivity.java : pembungkus Android WebView
- konfigurasi proyek Android Gradle

CARA MEMBUAT APK:
1. Instal Android Studio pada komputer/laptop.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder UangKeluargaAndroid.
4. Tunggu Gradle Sync dan instal Android SDK Platform 35 bila diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
- Proyek ini adalah source project, bukan file APK yang sudah dikompilasi.
- APK perlu dibangun menggunakan Android Studio/Android SDK.
- Data aplikasi disimpan lokal pada perangkat melalui localStorage. Gunakan fitur
  cadangan JSON di menu Anggaran untuk backup rutin.
- Aplikasi ini tidak meminta akses internet atau izin kontak/lokasi.
